#include <stdint.h>

uint32_t modexp(uint32_t a, uint32_t b, uint32_t n) {
    uint32_t result = 1;
    a = a % n;

    while (b > 0) {
        if (b & 1) {
            result = (result * a) % n;
        }
        a = (a * a) % n;
        b >>= 1;
    }
    return result;
}
